// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

/* 
* This unification algorithm analyzes both x and y predicates at same time.
* Each terms in predicates are matched recursively by their type.
* When the recursive research reaches a variable term in either side, it start to unify_var function.
* This unify_var function searches substitute map whether selected variable is already allocated constant or not.
* If so, it start to unify with its value and given other term.
* If not, it start to search whether there is occur-check.
* If there is no occur-check, the given variable will be unified and allocated in substitute theta.
*
* In occur-check part, the first given term will search whether the second term has first term in its expression.
* When the first term travel second term recursively, it will return true if there is same term with first term.
* If not, occur-check function returns false, which mean there is no duplicated term.
*
* In standardizing apart function, second predicate is compared with first predicate.
* The function compare each terms iteratively and check duplication.
* If it finds a variable that need to be standardized, stringstream will add a distinguishable number.
*/ 

#include <iostream>
#include <sstream>
#include <cstdlib>
#include <string>
#include <cstring>
#include <map>
#include <set>
#include <utility>
#include <stdexcept>

#include "fol.hpp"
#include "fol-reader.hpp"

using namespace std;

struct Variable_Ptr_Comparer {
  bool operator() (const Variable* x, const Variable* y) const {
      return x->getName().compare(y->getName()) < 0;
  }
};

typedef map<Variable*,Term*,Variable_Ptr_Comparer> Substitute;

void unify(Substitute &theta, Predicate &x, Predicate &y);

bool occur_check(Predicate& var, Predicate& x) {

	if (x.getTerm(0).getType() != FUNCTION) {
		if (x.getTerm(0).getName() == var.getTerm(0).getName())
			return true;

		return false;
	}
	else {
		Function *now = (Function *)&x.getTerm(0);
		for (int i = 0; i < now->getTermSize(); i++) {
			vector<Term*> temp_vec;
			temp_vec.push_back(&(now->getTerm(i)));
			Predicate *temp = new Predicate("", temp_vec);
			if (occur_check(var, *temp)) {
				return true;
			}
		}
	}

	return false;
}


void unify_var (Predicate &var, Predicate &x, Substitute &theta) {

	if (var.getTerm(0).getType() == VARIABLE && theta.find((Variable*)&var.getTerm(0)) != theta.end()) {
		vector<Term*> val_vec;
		val_vec.push_back(theta.find((Variable*)&var.getTerm(0))->second);

		Predicate *temp = new Predicate("", val_vec);
		unify(theta, *temp, x);
		return;
	}
	else if (x.getTerm(0).getType() == VARIABLE && theta.find((Variable *)&x.getTerm(0)) != theta.end()) {
		vector<Term*> val_vec;
		val_vec.push_back(theta.find((Variable*)&x.getTerm(0))->second);

		Predicate *temp = new Predicate("", val_vec);
		unify(theta, *temp, var);
		return;
	}
	else if (occur_check(var, x)) {
		throw runtime_error("Occur check failed.");
	}
	else {
		theta.insert(make_pair((Variable *)&var.getTerm(0), &x.getTerm(0)));
	}

	return;
}

void unify(Substitute &theta, Predicate &x, Predicate &y) {

	if (x.getTermSize() != y.getTermSize()) {
		throw runtime_error("Predicate argument number mismatched.");
	}

	if (x.getName() != y.getName()) {
		throw runtime_error("Different predicate names.");
	}
	
	if (x.equals(y)) {
		return;
	}
	else {
		// x->Variable?
		if (x.getTermSize() == 1 && x.getTerm(0).getType() == VARIABLE) {
			unify_var(x, y, theta);
			return;
		}
		// y->Variable?
		else if (y.getTermSize() == 1 && y.getTerm(0).getType() == VARIABLE) {
			unify_var(y, x, theta);
			return;
		}
		// x->Compound and y->Compound?
		else if (x.getName() != "" && y.getName() != "") {
			vector<Term*> x_list;
			vector<Term*> y_list;

			Predicate *x_op = new Predicate(x.getName(), x_list);
			Predicate *y_op = new Predicate(y.getName(), y_list);

			unify(theta, *x_op, *y_op);

			for (int i = 0; i < x.getTermSize(); i++) {
				x_list.push_back(&(x.getTerm(i)));
			}

			for (int i = 0; i < y.getTermSize(); i++) {
				y_list.push_back(&(y.getTerm(i)));
			}

			Predicate *x_arg = new Predicate ("", x_list);
			Predicate *y_arg = new Predicate ("", y_list);
			unify(theta, *x_arg, *y_arg);
			return;
		}
		// x->list and y->list?
		else if ((x.getName() == "" && x.getTermSize() > 1) && (y.getName() == "" && y.getTermSize() > 1)) {
			vector<Term*> x_1st_term;
			x_1st_term.push_back(&(x.getTerm(0)));

			vector<Term*> y_1st_term;
			y_1st_term.push_back(&(y.getTerm(0)));

			Predicate *x_first = new Predicate("", x_1st_term);
			Predicate *y_first = new Predicate("", y_1st_term);
			unify(theta, *x_first, *y_first);

			vector<Term*> x_rest_list;
			for (int i = 1; i < x.getTermSize(); i++) {
				x_rest_list.push_back(&(x.getTerm(i)));
			}

			vector<Term*> y_rest_list;
			for (int i = 1; i < y.getTermSize(); i++) {
				y_rest_list.push_back(&(y.getTerm(i)));
			}

			Predicate *x_rest = new Predicate("", x_rest_list);
			Predicate *y_rest = new Predicate("", y_rest_list);
			unify(theta, *x_rest, *y_rest);
		}
		else {
			throw runtime_error("Unable to unify terms.");
		}
	}

	return;
}


pair<Predicate*,Predicate*> standandizing_apart(Predicate *p1, Predicate *p2) {

	int cnt = 1;
	vector<Term*> new_p1_vec;
	vector<Term*> new_p2_vec;

	for (int i = 0; i < p2->getTermSize(); i++) {
		if (p2->getTerm(i).getType() != VARIABLE) {
			new_p2_vec.push_back(&(p2->getTerm(i)));
			continue;
		}

		for (int j = 0; j < p1->getTermSize(); j++) {
			if (p1->getTerm(j).getType() != VARIABLE)
				continue;

			if (p2->getTerm(i).getName() == p1->getTerm(j).getName()) {
				stringstream i_to_s;
				i_to_s << cnt;
				cnt++;

				Variable *new_var = new Variable(p2->getTerm(i).getName() + "_" + i_to_s.str());
				new_p2_vec.push_back(new_var);
			}
		}
	}

	for (int i = 0; i < p1->getTermSize(); i++) {
		new_p1_vec.push_back(&(p1->getTerm(i)));
	}

	Predicate *new_p1 = new Predicate(p1->getName(), new_p1_vec);
	Predicate *new_p2 = new Predicate(p2->getName(), new_p2_vec);
    return make_pair(new_p1, new_p2);
}


/*
 * Printing
 */
void print(Term &x, Substitute &theta) {
    if (x.getType() == VARIABLE && theta.count(dynamic_cast<Variable*>(&x)) > 0) {
        print(*theta[dynamic_cast<Variable*>(&x)], theta);
    } else if (x.getType() == FUNCTION) {
        Function& f = dynamic_cast<Function&>(x);
        cout << f.getName() << "(";
        for(int i=0; i<f.getTermSize(); i++) {
            if (i != 0) cout << ", ";
            print(f.getTerm(i), theta);
        }
        cout << ")";
    } else {
        cout << x;
    }
}

/*
 * The main function.
 */
int main(int argc, char **argv) {

    bool isArgValid = true;
    bool isStandardizingApart = false;

    if (argc==2) {
        if (strcmp(argv[1], "-s")==0) {
           isStandardizingApart = true;
        } else {
            isArgValid = false;
        }
    } else if (argc > 2) {
        isArgValid = false;
    }

    if (!isArgValid) {
        cerr << "Error in command line arguments." << endl;
        cerr << endl;
        cerr << "Usage: " << endl;
        cerr << "       " << argv[0] << " [-s]" << endl;
        cerr << endl;
        cerr << "The option -s enables standardizing apart." << endl;
        return 1;
    }

    fol_reader reader;

    cout << "Please enter the first predicate: ";
    Predicate *p1 = reader.read();
    if (!p1) { 
        cerr << "Error when reading from STDIN." << endl;
        return 2;
    }

    cout << "Please enter the second predicate: ";
    Predicate *p2 = reader.read();
    if (!p2) { 
        cerr << "Error when reading from STDIN." << endl;
        return 3;
    }

    if (isStandardizingApart) {
        pair<Predicate*,Predicate*> pair = standandizing_apart(p1, p2);
        //delete p1;
        //delete p2;
        p1 = pair.first;
        p2 = pair.second;
        cout << "After standardizing apart, the predicates are:" << endl;
        cout << "    " << *p1 << endl;
        cout << "    " << *p2 << endl;
    }

    Substitute theta;

    try {
        unify(theta, *p1, *p2);
    } catch(const runtime_error& e) {
        cout << "Unification failed: " << e.what() << endl;
        exit(EXIT_FAILURE);
    }

    cout << "The substitution is:" << endl;
    for(Substitute::iterator iter = theta.begin(); iter != theta.end(); ++iter) {
        cout << "    " << *(iter->first) << " := ";
        print(*iter->second, theta);
        cout << endl;
    }

    delete p1;
    delete p2;
}


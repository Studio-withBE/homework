// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <utility>
#include <list>

#define P pair<int, int>

using namespace std;

/*
 * The n-queens problem solver
 * 
 * size      - the number of queens
 * isVerbose - whether the intermediate nodes are displayed
 */

int  N;
int  verbose_cnt;
bool switch_verbose;

void print_chess (vector<int> chess) {

	if (switch_verbose == true) {
	
		for (int i = 0; i < N; i++)
			cout << "-";

		if (verbose_cnt == -1) {
			cout << " Solution" << endl;
		} else {
			cout << " " << verbose_cnt << endl;
			verbose_cnt++;
		}
	}

	for (int i = 0; i < N; i++) {
	
		string line = "";

		for (int j = 0; j < N; j++)
			line += "*";

		if (chess[i] != -1)
			line[chess[i]] = 'Q';

		cout << line << endl;
	}
}


bool isDone (vector<int> chess) {

	for (int i = 0; i < N; i++) {
		if (chess[i] == -1)
			return false;
	}

	return true;
}


int get_cnt_attack (vector<int> chess) {

	int result = 0;

	for (int col1 = 0; col1 < N; col1++) {
		
		if (chess[col1] == -1)
			continue;

		for (int col2 = 0; col2 < N; col2++) {

			if (chess[col2] == -1)
				continue;

			if (chess[col1] == chess[col2]) {
				result++;
			} else if (abs(col1 - col2) == abs(chess[col1] - chess[col2])) {
				result++;
			}
		}
	}

	return result;
}


bool is_valid (vector<int> chess, int r, int c) {

	if (chess[c] != -1)
		return false;

	for (int i = 0; i < N; i++) {
		if (chess[i] == r || abs(c-i) == abs(r-chess[i]))
			return false;
	}

	return true;
}


list<P> MRV (vector<int> chess, int now_row) {

	list<P> result;

	for (int row = 0; row < N; row++) {

		int cnt = 0;

		if (row == now_row)
			continue;

		for (int col = 0; col < N; col++) {
			if (is_valid(chess, row, col) == true)
				cnt++;
		}

		result.push_back(make_pair(cnt, row));
	}

	result.sort();
	return result;
}

list<P> LCV (vector<int> chess, int target_row) {

	list<P> result;

	for (int col = 0; col < N; col++) {

		if (chess[col] != -1)
			continue;

		if (is_valid(chess, target_row, col) == true) {
			chess[col] = target_row;
			int cnt    = get_cnt_attack(chess);
			
			chess[col] = -1;
			result.push_back(make_pair(N*N - cnt, col));
		}
	}

	result.sort();
	return result;
}


bool backtracking_solve (vector<int> chess, int now_row) {

	if (isDone(chess) == true) {
		verbose_cnt = -1;
		print_chess(chess);
		return true;
	}

	if (switch_verbose == true)
		print_chess(chess);

	list<P> next_row = MRV(chess, now_row);

	while (!next_row.empty()) {

		int     new_row  = next_row.front().second;
		list<P> next_col = LCV(chess, new_row);

		while (!next_col.empty()) {

			int new_col    = next_col.front().second;
			chess[new_col] = new_row;

			if (backtracking_solve(chess, new_row) == true)
				return true;

			next_col.pop_front();
			chess[new_col] = -1;
		}

		next_row.pop_front();
	}

	return false;
}


void solve_nqueen(int size, bool isVerbose) {

    N 			   = size;
	verbose_cnt    = 0;
	switch_verbose = isVerbose;
	
	vector<int> chess;

	for (int i = 0; i < size; i++)
		chess.push_back(-1);

	for (int row = 0; row < N; row++) {
		
		chess[0] = row;

		if ( backtracking_solve(chess, 0) == true )
			return;

		chess[0] = -1;
	}

	cout << "Solution not found. Solution may not exist." << endl;
}

/*
 * The main function.
 */
int main(int argc, char** argv) {

    int size;
    bool isVerbose = false, isArgValid = true;

    if (argc==2) {
        size = atoi(argv[1]);
        isArgValid = (size>0);
    } else if (argc==3) {
        if (strcmp(argv[1], "-v")==0) {
            isVerbose = true;
            size = atoi(argv[2]);
            isArgValid = (size>0);
        } else {
            isArgValid = false;
        }
    } else {
        isArgValid = false;
    }

    if (!isArgValid) {
        cout << "Error in command line arguments." << endl;
        cout << "Usage: " << argv[0] << " [-v] n" << endl;
        cout << "where n is the number of queens and the size of the board (nxn)." << endl;
        cout << "The option -v enables the output of the intermediate states of" << endl;
        cout << "the search procedure." << endl;
        return 1;
    }

    solve_nqueen(size, isVerbose);
    
    return 0;
}


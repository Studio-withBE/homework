backtraking with LCV & MRV
=> maximum N=15 (within 2 minutes)

minconflict
=> maximum N=68 (within 5 consecutive N value and 2 minutes)

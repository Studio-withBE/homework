// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

#include <iostream>
#include <cstring>
#include <cstdlib>
#include <vector>
#include <cmath>
#include <ctime>

using namespace std;

/*
 * The n-queens problem solver
 * 
 * size      - the number of queens
 * isVerbose - whether the intermediate nodes are displayed
 */


vector<int> location;
int 		N;
int 		last_moved_col;


void print_chess() {

	char chess[N][N];

	for (int r = 0; r < N; r++) {	
		for (int c = 0; c < N; c++) {

			if (location[c] == r)
				chess[r][c] = 'Q';
			else
				chess[r][c] = '*';
		}
	}

	for (int r = 0; r < N; r++) {

		for (int c = 0; c < N; c++)
			cout << chess[r][c];
		cout << endl;
	}
}


vector<int> check_conflict() {

	vector<int> result;

	for (int col = 0; col < N; col++) {
	
		int row = location[col];
		int num = 0;

		for (int i = 0; i < N; i++) {
		
			if (i == col)
				continue;

			if (row == location[i] || abs(col - i) == abs(row - location[i]))
				num++;
		}
		
		result.push_back(num);
	}

	return result;
}


bool isSolution(vector<int> conflict) {

	for (int i = 0; i < N; i++){
		if (conflict[i] != 0)
			return false;
	}

	return true;
}


int get_random_col(int last) {

	int col;

	while (true) {
		col = rand() % N;
		if (col != last)
			break;
	}

	return col;
}


int move(int col) {

	int 		now_row = location[col];
	int 		minimum = 100000000;
	int 	    new_row;
	vector<int> target;

	for (int r = 0; r < N; r++) {

		int num = 0;

		for (int c = 0; c < N; c++) {
			if (c == col)
				continue;

			if (r == location[c] || abs(c - col) == abs(r - location[c]))
				num++;
		}

		target.push_back(num);

		if (minimum > num)
			minimum = num;
	}

	while (true) {
		new_row = rand() % N;
		if (target[new_row] == minimum)
			break;
	}

	return new_row;
}

void solve_nqueen(int size, bool isVerbose) {

	N 			   = size;
	last_moved_col = -1;

	srand((unsigned int)time(NULL));

    for (int i = 0; i < size; i++)
		location.push_back(i);

	for (int iter = 0; iter < 1000; iter++) {
		vector<int> conflict = check_conflict();

		if (isSolution(conflict) == true) {
			if (isVerbose == true) {
				for (int i = 0; i < size; i++)
					cout << "-";
				cout << " Solution" << endl;
			}

			print_chess();
			return;
		}

		int col 	   = get_random_col(last_moved_col);

		last_moved_col = col;
		location[col]  = move(col);

		if (isVerbose == true) {
		
			for (int i = 0; i < size; i++)
				cout << "-";

			cout << " " << iter << endl;
			print_chess();
		}
	}

	cout << "Solution not found. Solution may not exist." << endl;
}

/*
 * The main function.
 */
int main(int argc, char** argv) {

    int size;
    bool isVerbose = false, isArgValid = true;

    if (argc==2) {
        size = atoi(argv[1]);
        isArgValid = (size>0);
    } else if (argc==3) {
        if (strcmp(argv[1], "-v")==0) {
            isVerbose = true;
            size = atoi(argv[2]);
            isArgValid = (size>0);
        } else {
            isArgValid = false;
        }
    } else {
        isArgValid = false;
    }

    if (!isArgValid) {
        cout << "Error in command line arguments." << endl;
        cout << "Usage: " << argv[0] << " [-v] n" << endl;
        cout << "where n is the number of queens and the size of the board (nxn)." << endl;
        cout << "The option -v enables the output of the intermediate states of" << endl;
        cout << "the search procedure." << endl;
        return 1;
    }

    solve_nqueen(size, isVerbose);
    
    return 0;
}


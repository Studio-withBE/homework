//
// dfs.cpp - Version 1.0
//
// Please write your name, your student ID, and your email address here.
// Moreover, please describe the implementation of your functions here.
// You will have to submit this file.
//
// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

#include <iostream>
#include <list>
#include <string>
#include <cstdlib>

// ---------------------------------------------------------------------
// Include the optional header with backward compatibility
// see http://codereview.stackexchange.com/questions/136350/seamlessly-migrating-experimental-optional-to-optional
#if __has_include(<optional>)
#   include <optional>
namespace stdx {
  using namespace ::std;
}
#elif __has_include(<experimental/optional>)
#   include <experimental/optional>
namespace stdx {
  using namespace ::std;
  using namespace ::std::experimental;
}
#else
#   error <experimental/optional> and <optional> not found
#endif

using namespace stdx;
// ---------------------------------------------------------------------


#define MAX_SIZE 300

class Coordinate {

  int x, y;

public:
  Coordinate(){}
  Coordinate(int x, int y) : x(x), y(y) {}

  int getX() const {
    return x;
  }

  int getY() const {
    return y;
  }

  bool operator==(const Coordinate &rhs) const {
    return x == rhs.x && y == rhs.y;
  }

  bool operator!=(const Coordinate &rhs) const {
    return !(rhs == *this);
  }
};

class DepthFirstSearchAgent {

private:

	int x_size, y_size;
	int x_goal, y_goal;
	int x_now, y_now;
	int length;

	list<Coordinate> stack;
	bool visit[MAX_SIZE * 2][MAX_SIZE * 2];
	bool map[MAX_SIZE * 2][MAX_SIZE * 2];

public:

  DepthFirstSearchAgent(int size_x, int size_y) {

    // enter your code here
	  x_now = 0;
	  y_now = 0;
	  x_size = size_x;
	  y_size = size_y;
	  length = 10000000;

	  stack.push_back(Coordinate(0, 0));
	  
	  for (int i = 0; i < MAX_SIZE * 2; i++)
	  {
		  for (int j = 0; j < MAX_SIZE * 2; j++)
		  {
			  visit[i][j] = false;
			  map[i][j] = false;
		  }
	  }

	  visit[MAX_SIZE][MAX_SIZE] = true;
  }

  optional<Coordinate> move(bool isExit, bool hasWallSouth, bool hasWallNorth, bool hasWallEast, bool hasWallWest) {

    // enter your code here

	if (hasWallSouth == true)
	{
		map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = true;
		visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = true;
	}

	if (hasWallNorth == true)
	{
		map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = true;
		visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = true;
	}

	if (hasWallEast == true)
	{
		map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = true;
		visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = true;
	}

	if (hasWallWest == true)
	{
		map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = true;
		visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = true;
	}

	if (isExit == false)
  	{
		if (hasWallSouth == false && visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == false)
			stack.push_back(Coordinate(x_now, y_now + 1));

		if (hasWallNorth == false && visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == false)
			stack.push_back(Coordinate(x_now, y_now - 1));

		if (hasWallEast == false && visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == false)
			stack.push_back(Coordinate(x_now + 1, y_now));

		if (hasWallWest == false && visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == false)
			stack.push_back(Coordinate(x_now - 1, y_now));

		if (visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == true &&
			visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == true &&
			visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == true &&
			visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == true)
		{
			Coordinate temp(x_now, y_now);

			while(true)
			{
				stack.pop_back();
				Coordinate temp = stack.back();

				x_now = temp.getX();
				y_now = temp.getY();

				if (visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == false ||
					visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == false ||
					visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == false ||
					visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == false)
				{
					break;
				}

				if (stack.empty())
					return {};
			}
		}
	}
	else
	{
		x_goal = x_now;
		y_goal = y_now;

		if (Coordinate(0, 0) == Coordinate(x_goal, y_goal))
			return {};

		while(true)
		{
			stack.pop_back();
			Coordinate temp = stack.back();

			x_now = temp.getX();
			y_now = temp.getY();

			if (visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == false ||
				visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == false ||
				visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == false ||
				visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == false)
			{
				break;
			}

			if (stack.empty())
				return {};
		}
	}

	Coordinate now = stack.back();

	x_now = now.getX();
	y_now = now.getY();
	visit[MAX_SIZE + y_now][MAX_SIZE + x_now] = true;

	return now;
  }

  list<Coordinate> getShortestPath() {

    // enter your code here
	list<Coordinate> result;
	list<Coordinate> queue;
	Coordinate trace[MAX_SIZE * 2][MAX_SIZE * 2];

	Coordinate temp(0, 0);
	queue.push_back(temp);

	while (!queue.empty())
	{
		temp = queue.front();
		int x = temp.getX();
		int y = temp.getY();
		map[MAX_SIZE + y][MAX_SIZE + x] = true;

		if (x == x_goal && y == y_goal)
			break;

		if (map[MAX_SIZE + y + 1][MAX_SIZE + x] == 0)
		{
			queue.push_back(Coordinate(x, y + 1));
			trace[MAX_SIZE + y + 1][MAX_SIZE + x] = Coordinate(x, y);
		}
		if (map[MAX_SIZE + y - 1][MAX_SIZE + x] == 0)
		{
			queue.push_back(Coordinate(x, y - 1));
			trace[MAX_SIZE + y - 1][MAX_SIZE + x] = Coordinate(x, y);
		}
		if (map[MAX_SIZE + y][MAX_SIZE + x + 1] == 0)
		{
			queue.push_back(Coordinate(x + 1, y));
			trace[MAX_SIZE + y][MAX_SIZE + x + 1] = Coordinate(x, y);
		}
		if (map[MAX_SIZE + y][MAX_SIZE + x - 1] == 0)
		{
			queue.push_back(Coordinate(x - 1, y));
			trace[MAX_SIZE + y][MAX_SIZE + x - 1] = Coordinate(x, y); 
		}

		queue.pop_front();
	}

	temp = Coordinate(x_goal, y_goal);

	while (true)
	{
		result.push_front(temp);
		
		if (result.front() == Coordinate(0, 0))
			break;

		temp = trace[MAX_SIZE + temp.getY()][MAX_SIZE + temp.getX()];
	}

	return result;
  }

};

int main(int argc, char *argv[]) {

  int size_x, size_y;

  if (argc == 3) {
    size_x = atoi(argv[1]);
    size_y = atoi(argv[2]);
  } else {
    cerr << "Error: wrong arguments." << endl;
    return -1;  // do nothing
  }

  DepthFirstSearchAgent agent(size_x, size_y);

  while(true) {
    string s1, s2, s3, s4, s5;
    cin >> s1 >> s2 >> s3 >> s4 >> s5;

    bool isExit = (s1 != "0");
    bool hasWallSouth = (s2 != "0");
    bool hasWallNorth = (s3 != "0");
    bool hasWallEast = (s4 != "0");
    bool hasWallWest = (s5 != "0");

    auto coord = agent.move(isExit, hasWallSouth, hasWallNorth, hasWallEast, hasWallWest);

    if (coord) {
      cout << coord->getX() << " " << coord->getY() << endl;
    } else {
      break;
    }
  }

  list<Coordinate> path = agent.getShortestPath();

  cout << "PATH" << endl;
  for(auto&& coord : path) {
    cout << coord.getX() << " " << coord.getY() << endl;
  }
  cout << "END" << endl;

  return 0;
}


//
// bfs.cpp - Version 1.0
//
// Please write your name, your student ID, and your email address here.
// Moreover, please describe the implementation of your functions here.
// You will have to submit this file.
//

// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

#include <iostream>
#include <list>
#include <string>
#include <cstdlib>

// ---------------------------------------------------------------------
// Include the optional header with backward compatibility
// see http://codereview.stackexchange.com/questions/136350/seamlessly-migrating-experimental-optional-to-optional
#if __has_include(<optional>)
#   include <optional>
namespace stdx {
  using namespace ::std;
}
#elif __has_include(<experimental/optional>)
#   include <experimental/optional>
namespace stdx {
  using namespace ::std;
  using namespace ::std::experimental;
}
#else
#   error <experimental/optional> and <optional> not found
#endif

using namespace stdx;
// ---------------------------------------------------------------------


#define MAX_SIZE 300


class Coordinate {

  int x, y;

public:
  Coordinate(){}
  Coordinate(int x, int y) : x(x), y(y) {}

  int getX() const {
    return x;
  }

  int getY() const {
    return y;
  }

  bool operator==(const Coordinate &rhs) const {
    return x == rhs.x && y == rhs.y;
  }

  bool operator!=(const Coordinate &rhs) const {
    return !(rhs == *this);
  }

  Coordinate(const Coordinate& target)
  {
    this->x = target.x;
	this->y = target.y;
  }
};


class BreadthFirstSearchAgent {

private:

	int x_size, y_size;
	int x_goal, y_goal;
	int x_now , y_now;

	list<Coordinate> queue;

	bool visit[MAX_SIZE * 2][MAX_SIZE * 2];
	Coordinate trace[MAX_SIZE * 2][MAX_SIZE * 2];

public:

  BreadthFirstSearchAgent(int size_x, int size_y) {

    // enter your code here
    this->x_size = size_x;
    this->y_size = size_y;
    this->x_now = 0;
    this->y_now = 0;
	this->x_goal = -600;
	this->y_goal = -600;

	for (int i = 0; i < MAX_SIZE*2; i++)
		for(int j = 0; j < MAX_SIZE*2; j++)
			visit[i][j] = false;

  }

  optional<Coordinate> move(bool isExit, bool hasWallSouth, bool hasWallNorth, bool hasWallEast, bool hasWallWest) {

    // enter your code here

	if (isExit == true)
	{
		x_goal = x_now;
		y_goal = y_now;
		return {};
	}
	else
	{
		Coordinate pre(x_now, y_now);

		if (hasWallSouth == false && visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == false)
		{
			Coordinate temp(x_now, y_now + 1);
			trace[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = pre;
			visit[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = true;
			queue.push_back(temp);
		}

		if (hasWallNorth == false && visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == false)
		{
			Coordinate temp(x_now, y_now - 1);
			trace[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = pre;
			visit[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = true;
			queue.push_back(temp);
		}

		if (hasWallEast == false && visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == false)
		{
			Coordinate temp(x_now + 1, y_now);
			trace[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = pre;
			visit[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = true;
			queue.push_back(temp);
		}

		if (hasWallWest == false && visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == false)
		{
			Coordinate temp(x_now - 1, y_now);
			trace[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = pre;
			visit[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = true;
			queue.push_back(temp);
		}

		Coordinate now = queue.front();
		x_now = now.getX();
		y_now = now.getY();
		queue.pop_front();

		return now;
	}

  }

  list<Coordinate> getShortestPath() {

    // enter your code here
    list<Coordinate> result;
    Coordinate temp(this->x_goal, this->y_goal);
	Coordinate start(0, 0);
    result.push_front(temp);

    while(temp != start)
    {
        temp = trace[MAX_SIZE + temp.getY()][MAX_SIZE + temp.getX()];
        result.push_front(temp);
    }

    return result;
  }

};


int main(int argc, char *argv[]) {

  int size_x, size_y;

  if (argc == 3) {
    size_x = atoi(argv[1]);
    size_y = atoi(argv[2]);
  } else {
    cerr << "Error: wrong arguments." << endl;
    return -1;  // do nothing
  }

  BreadthFirstSearchAgent agent(size_x, size_y);

  while(true) {
    string s1, s2, s3, s4, s5;
    cin >> s1 >> s2 >> s3 >> s4 >> s5;

    bool isExit = (s1 != "0");
    bool hasWallSouth = (s2 != "0");
    bool hasWallNorth = (s3 != "0");
    bool hasWallEast = (s4 != "0");
    bool hasWallWest = (s5 != "0");

    auto coord = agent.move(isExit, hasWallSouth, hasWallNorth, hasWallEast, hasWallWest);

    if (coord) {
      cout << coord->getX() << " " << coord->getY() << endl;
    } else {
      break;
    }
  }

  list<Coordinate> path = agent.getShortestPath();

  cout << "PATH" << endl;
  for(auto&& coord : path) {
    cout << coord.getX() << " " << coord.getY() << endl;
  }
  cout << "END" << endl;

  return 0;
}

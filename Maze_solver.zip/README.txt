CSE46201
Hyunjoon Jeong 20151509
with1015@unist.ac.kr

1. BFS search

In my algorithm, BFS always guarantees the shortest path. It uses queue to determine next coordinate to visit.
The BFS algorithm's average performance depends on the shortest length to the goal and the average number of node in the shortest length.
The BFS algorithm in my code follow below sequences.

 1) Check whether place is goal or not.
 2) Check four direction whether there are walls or not and already visited or not.
 3) If the direction is not visited and no wall, push back to the queue and record now coordinate for tracing.
 4) Pop the element from the front of queue and set the now position.


2. A* search

In my algorithm, A* also always shows the shortest path. It uses priority queue to determine next coordinate to visit.
The algorithm shows better time performance than the BFS algorithm.
However, it is worse than BFS in terms of space complexity. 
The algorithm in my code follows below sequences.

 1) Check whether place is goal or not.
 2) Check g + h = f
 3) Check four direction whether there are walls or not and closed list already calcuate the f value or not.
 4) If the direction can be updated by condition, update the direction and push back to open list.
 5) Save the direction in array for tracing.
 6) Sort the open list by f value order.
 7) Pop the element from the front of queue and set the now position.


3. DFS search

In my DFS algorithm, the agent just draws whole map by using DFS. So, the algorithm should travel all empty space.
The number of movement will be always same as the number of empty space (that is, same as the number of no wall place.)
The agent records whole map, then it start to solve the shortest path.The advantage of this algorithm is, it always move as the number of empty places.
However, it is disadvantage for the map where have really short path. The algorithm in my DFS code follow below sequences.

 1) Check four direction where is the wall.
 2) If there is the wall, mark in the map array.
 3) Check whether now position is goal. If so, save the goal and pop the stack until not visited position.
 4) If the position is not goal, check four directions. The direction, where is no wall and not visited, push back to stack.
 5) If the position is dead-end, pop the stack until not visited position.
 6) Set current position to the back element of the stack and mark in visited map.



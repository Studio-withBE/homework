//
// astar.cpp - Version 1.0
//
// Please write your name, your student ID, and your email address here.
// Moreover, please describe the implementation of your functions here.
// You will have to submit this file.
//
// 20151509 Hyunjoon Jeong
// with1015@unist.ac.kr

#include <iostream>
#include <list>
#include <string>
#include <cstdlib>

// ---------------------------------------------------------------------
// Include the optional header with backward compatibility
// see http://codereview.stackexchange.com/questions/136350/seamlessly-migrating-experimental-optional-to-optional
#if __has_include(<optional>)
#   include <optional>
namespace stdx {
  using namespace ::std;
}
#elif __has_include(<experimental/optional>)
#   include <experimental/optional>
namespace stdx {
  using namespace ::std;
  using namespace ::std::experimental;
}
#else
#   error <experimental/optional> and <optional> not found
#endif

using namespace stdx;
// ---------------------------------------------------------------------


#define MAX_SIZE 300

#define SOUTH       1
#define NORTH       2
#define EAST        3
#define WEST        4
#define HIGH_DOUBLE 1000

class Coordinate {

  int x, y;

public:
  Coordinate(){}
  Coordinate(int x, int y) : x(x), y(y) {}

  int getX() const {
    return x;
  }

  int getY() const {
    return y;
  }

  bool operator==(const Coordinate &rhs) const {
    return x == rhs.x && y == rhs.y;
  }

  bool operator!=(const Coordinate &rhs) const {
    return !(rhs == *this);
  }
};

typedef struct Location{

	Coordinate loc;

	int    prev;
	int    g;
	double h;
	double f;

}Location;

bool f_sort (const Location& a, const Location& b) {

	return a.h + a.g < b.h + b.g;
}

int prev_dir[MAX_SIZE * 2][MAX_SIZE * 2];

class AStarFirstSearchAgent {

private:

	int x_size, y_size;
	int x_goal, y_goal;
	int x_now, y_now;
	int depth;

	list<Location> open_list;

	int    g_map[MAX_SIZE * 2][MAX_SIZE * 2];
	double h_map[MAX_SIZE * 2][MAX_SIZE * 2];
	double f_map[MAX_SIZE * 2][MAX_SIZE * 2];

	bool close_list[MAX_SIZE * 2][MAX_SIZE * 2];
	
public:

  AStarFirstSearchAgent(int size_x, int size_y) {

    // enter your code here
	x_size = size_x;
	y_size = size_y;
	x_now = 0;
	y_now = 0;
	depth = 0;

	for (int i = 0; i < MAX_SIZE * 2; i++)
	{
		for (int j = 0; j < MAX_SIZE * 2; j++)
		{
			close_list[i][j] = false;
			prev_dir[i][j] = 0;
			g_map[i][j] = 0;
			h_map[i][j] = HIGH_DOUBLE;
			f_map[i][j] = HIGH_DOUBLE;
		}
	}

	close_list[MAX_SIZE][MAX_SIZE] = true;
  }

  optional<Coordinate> move(bool isExit, bool hasWallSouth, bool hasWallNorth, bool hasWallEast, bool hasWallWest, double distance) {
  
    // enter your code here

	if (isExit == true)
	{
		x_goal = x_now;
		y_goal = y_now;
		return {};
	}

	Coordinate now(x_now, y_now);

	int    new_g = depth + 1;
	double new_h = distance;
	double new_f = new_g + new_h;

	if (hasWallSouth == false &&
		close_list[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] == false)
	{
		Location temp;

		temp.loc = Coordinate(x_now, y_now + 1);
		temp.prev = SOUTH;
		temp.g = g_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now];
		temp.h = h_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now];
		temp.f = f_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now];

		if (temp.f > new_f || temp.f == HIGH_DOUBLE)
		{
			temp.g = new_g;
			temp.h = new_h;
			temp.f = new_f;
			
			open_list.push_back(temp);

			g_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = new_g;
			h_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = new_h;
			f_map[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = new_f;

			prev_dir[MAX_SIZE + y_now + 1][MAX_SIZE + x_now] = temp.prev;
		}
	}

	if (hasWallNorth == false &&
		close_list[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] == false)
	{
		Location temp;

		temp.loc = Coordinate(x_now, y_now - 1);
		temp.prev = NORTH;
		temp.g = g_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now];
		temp.h = h_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now];
		temp.f = f_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now];

		if (temp.f > new_f || temp.f == HIGH_DOUBLE)
		{
			temp.g = new_g;
			temp.h = new_h;
			temp.f = new_f;

			open_list.push_back(temp);

			g_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = new_g;
			h_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = new_h;
			f_map[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = new_f;
			
			prev_dir[MAX_SIZE + y_now - 1][MAX_SIZE + x_now] = temp.prev;
		}
	}

	if (hasWallEast == false &&
		close_list[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] == false)
	{
		Location temp;

		temp.loc = Coordinate(x_now + 1, y_now);
		temp.prev = EAST;
		temp.g = g_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1];
		temp.h = h_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1];
		temp.f = f_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1];

		if (temp.f > new_f || temp.f == HIGH_DOUBLE)
		{
			temp.g = new_g;
			temp.h = new_h;
			temp.f = new_f;

			open_list.push_back(temp);

			g_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = new_g;
			h_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = new_h;
			f_map[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = new_f;

			prev_dir[MAX_SIZE + y_now][MAX_SIZE + x_now + 1] = temp.prev;
		}
	}

	if (hasWallWest == false &&
		close_list[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] == false)
	{
		Location temp;

		temp.loc = Coordinate(x_now - 1, y_now);
		temp.prev = WEST;
		temp.g = g_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1];
		temp.h = h_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1];
		temp.f = f_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1];

		if (temp.f > new_f || temp.f == HIGH_DOUBLE)
		{
			temp.g = new_g;
			temp.h = new_h;
			temp.f = new_f;
			temp.prev = WEST;

			open_list.push_back(temp);

			g_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = new_g;
			h_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = new_h;
			f_map[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = new_f;

			prev_dir[MAX_SIZE + y_now][MAX_SIZE + x_now - 1] = temp.prev;
		}
	}

	close_list[MAX_SIZE + y_now][MAX_SIZE + x_now] = true;

	open_list.sort(f_sort);
	now = open_list.front().loc;
	open_list.pop_front();

	x_now = now.getX();
	y_now = now.getY();

	depth = g_map[MAX_SIZE + y_now][MAX_SIZE + x_now];

	return Coordinate(x_now, y_now);
  }

  list<Coordinate> getShortestPath() {
    
    // enter your code here
	list<Coordinate> result;
	Coordinate start(0, 0);
	Coordinate now(x_goal, y_goal);

	while (now != start)
	{
		int dir = prev_dir[MAX_SIZE + now.getY()][MAX_SIZE + now.getX()];
		result.push_front(now);

		switch (dir)
		{
			case SOUTH:
				now = Coordinate(now.getX(), now.getY() - 1);
				break;
			case NORTH:
				now = Coordinate(now.getX(), now.getY() + 1);
				break;
			case EAST:
				now = Coordinate(now.getX() - 1, now.getY());
				break;
			case WEST:
				now = Coordinate(now.getX() + 1, now.getY());
				break;
		}

	}

	result.push_front(now);
    return result;
  }

};

int main(int argc, char *argv[]) {

  int size_x, size_y;

  if (argc == 3) {
    size_x = atoi(argv[1]);
    size_y = atoi(argv[2]);
  } else {
    cerr << "Error: wrong arguments." << endl;
    return -1;  // do nothing
  }

  AStarFirstSearchAgent agent(size_x, size_y);

  while(true) {
    string s1, s2, s3, s4, s5, s6;
    cin >> s1 >> s2 >> s3 >> s4 >> s5 >> s6;

    bool isExit = (s1 != "0");
    bool hasWallSouth = (s2 != "0");
    bool hasWallNorth = (s3 != "0");
    bool hasWallEast = (s4 != "0");
    bool hasWallWest = (s5 != "0");
    double distance = stof(s6);

    auto coord = agent.move(isExit, hasWallSouth, hasWallNorth, hasWallEast, hasWallWest, distance);

    if (coord) {
      cout << coord->getX() << " " << coord->getY() << endl;
    } else {
      break;
    }
  }

  list<Coordinate> path = agent.getShortestPath();

  cout << "PATH" << endl;
  for(auto&& coord : path) {
    cout << coord.getX() << " " << coord.getY() << endl;
  }
  cout << "END" << endl;

  return 0;
}


